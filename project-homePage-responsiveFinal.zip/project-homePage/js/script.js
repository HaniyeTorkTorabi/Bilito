// ====== FAQ toggle ======
function toggleFaq(el) {
    // Close all other answers
    document.querySelectorAll('.faq-answer').forEach(ans => {
        if (ans !== el.nextElementSibling) ans.classList.remove('open');
    });
    document.querySelectorAll('.faq-question').forEach(q => {
        if (q !== el) {
            q.classList.remove('open');
            const img = q.querySelector('.faq-icon img');
            if (img) img.src = "../img/arrow-up-gray.png";
        }
    });

    // Toggle this one
    const answer = el.nextElementSibling;
    const iconImg = el.querySelector('.faq-icon img');
    const isOpen = answer.classList.toggle('open');
    el.classList.toggle('open');
    iconImg.src = isOpen
        ? "../img/arrow-up-blue.png"
        : "../img/arrow-up-gray.png";
}

// ====== Scroll-to-top (desktop & mobile) ======
document.querySelectorAll('.footer-bottom a').forEach(link => {
    link.addEventListener('click', e => {
        e.preventDefault();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
});

document.addEventListener('DOMContentLoaded', function() {
    // ====== LocalStorage helpers ======
    function getHistoryStorage() {
        return JSON.parse(localStorage.getItem('searchHistory') || '[]');
    }
    function saveHistoryStorage(arr) {
        localStorage.setItem('searchHistory', JSON.stringify(arr));
    }
    function addToHistoryStorage(text) {
        const arr = getHistoryStorage();
        if (!arr.includes(text)) {
            arr.push(text);
            saveHistoryStorage(arr);
        }
    }
    function removeFromHistoryStorage(text) {
        const arr = getHistoryStorage().filter(item => item !== text);
        saveHistoryStorage(arr);
    }
    function clearHistoryStorage() {
        localStorage.removeItem('searchHistory');
    }

    // ====== Render a single history item ======
    function renderHistoryItem(text) {
        const container = document.querySelector('.history-items');
        const itemEl = document.createElement('div');
        itemEl.className = 'history-item';
        itemEl.innerHTML = `
            <span class="item-text">${text}</span>
            <img src="../img/close-square.png" class="close-icon" alt="حذف">
        `;
        container.appendChild(itemEl);
    }

    // ====== 1) Initial sync of static HTML → localStorage if empty ======
    const staticTexts = Array.from(
        document.querySelectorAll('.history-item .item-text')
    ).map(el => el.textContent.trim());
    if (staticTexts.length && getHistoryStorage().length === 0) {
        // preserve original order
        saveHistoryStorage(staticTexts);
    }

    // ====== 2) Clear existing and render from storage ======
    const historyContainer = document.querySelector('.history-items');
    historyContainer.innerHTML = '';
    getHistoryStorage().forEach(renderHistoryItem);

    // ====== 3) Hamburger menu toggle ======
    const menuToggle = document.querySelector(".hamburger-menu");
    const navMenu    = document.querySelector(".main-nav");
    menuToggle?.addEventListener("click", () => {
        navMenu?.classList.toggle("show");
        navMenu?.classList.toggle("desktop-only");
    });

    // ====== 4) Auth modal open/close ======
    document.querySelectorAll('.btn-login').forEach(btn => {
        btn.addEventListener('click', e => {
            e.preventDefault();
            document.getElementById('auth-modal').classList.remove('hidden');
        });
    });
    document.querySelector("#auth-modal .close-btn")?.addEventListener('click', e => {
        e.preventDefault();
        document.getElementById('auth-modal').classList.add('hidden');
    });

    // ====== 5) Search button handler ======
    document.querySelectorAll('.search-btn').forEach(btn => {
        btn.addEventListener('click', e => {
            e.preventDefault();
            // Determine origin & destination
            let origin, destination;
            const desktopForm = document.querySelector('.form-fields');
            if (desktopForm && getComputedStyle(desktopForm).display !== 'none') {
                origin      = desktopForm.querySelector('input[placeholder="مبدا"]').value.trim();
                destination = desktopForm.querySelector('input[placeholder="مقصد"]').value.trim();
            } else {
                const selects = document.querySelectorAll('.form-fields-mobile select');
                origin      = selects[0].value;
                destination = selects[1].value;
            }
            if (!origin || !destination) return;
            const text = `${origin} به ${destination}`;
            addToHistoryStorage(text);
            renderHistoryItem(text);
            // … ادامهٔ لاجیک جستجو …
        });
    });

    // ====== 6) Remove single history item ======
    historyContainer.addEventListener("click", e => {
        const btn = e.target.closest(".close-icon");
        if (!btn) return;
        const itemEl = btn.closest(".history-item");
        const text = itemEl.querySelector(".item-text").innerText;
        itemEl.remove();
        removeFromHistoryStorage(text);
    });

    // ====== 7) Clear all history ======
    document.querySelector('.clear-all').addEventListener('click', e => {
        e.preventDefault();
        historyContainer.innerHTML = '';
        clearHistoryStorage();
    });

    // ===== Scroll History Left/Right =====
    const historyWrapper = document.querySelector('.history-items');
    const scrollBtns = document.querySelectorAll('.scroll-btn');
    const SCROLL_AMOUNT = 200; // پیکسل

    if (historyWrapper && scrollBtns.length === 2) {
        // ❮ اولی: اسکرول به چپ
        scrollBtns[0].addEventListener('click', () => {
            historyWrapper.scrollBy({ left: SCROLL_AMOUNT, behavior: 'smooth' });
        });
        // ❯ دومی: اسکرول به راست
        scrollBtns[1].addEventListener('click', () => {
            historyWrapper.scrollBy({ left: -SCROLL_AMOUNT, behavior: 'smooth' });
        });
    }

});
